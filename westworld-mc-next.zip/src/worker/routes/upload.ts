import { Hono } from "hono";
import type { AppEnv } from "../lib/auth";
import { requireAuth, requireAdmin } from "../lib/auth";
import { ok, fail } from "../lib/http";
import { logOp } from "../lib/log";

const app = new Hono<AppEnv>();

const MAX_AVATAR = 2 * 1024 * 1024; // 2MB
const MAX_IMAGE = 8 * 1024 * 1024; // 8MB
const ALLOWED: Record<string, string> = {
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/webp": ".webp",
  "image/gif": ".gif",
};

function extOf(type: string): string {
  return ALLOWED[type] || "";
}

/** 校验并保存到 R2，返回公开路径 */
async function saveToR2(
  c: { env: AppEnv["Bindings"] },
  key: string,
  body: ArrayBuffer,
  type: string,
): Promise<string> {
  const bucket = c.env.ASSETS;
  if (!bucket) throw new Error("R2 未绑定");
  await bucket.put(key, body, { httpMetadata: { contentType: type } });
  return `/static/${key}`;
}

// 上传头像（登录；限制 2MB，仅图片类型）
app.post("/avatar", requireAuth, async (c) => {
  const user = c.get("user")!;
  const form = await c.req.formData().catch(() => null);
  if (!form) return fail("无法解析上传内容");
  const file = form.get("file");
  if (!(file instanceof File)) return fail("缺少文件");
  if (file.size === 0 || file.size > MAX_AVATAR) return fail("头像需小于 2MB");
  const ext = extOf(file.type);
  if (!ext) return fail("仅支持 PNG / JPG / WEBP / GIF");
  const body = await file.arrayBuffer();
  const key = `uploads/avatars/${user.id}-${Date.now()}${ext}`;
  const url = await saveToR2(c, key, body, file.type);
  return ok({ url });
});

// 上传图库图片（登录；限制 8MB）
app.post("/image", requireAuth, async (c) => {
  const form = await c.req.formData().catch(() => null);
  if (!form) return fail("无法解析上传内容");
  const file = form.get("file");
  if (!(file instanceof File)) return fail("缺少文件");
  if (file.size === 0 || file.size > MAX_IMAGE) return fail("图片需小于 8MB");
  const ext = extOf(file.type);
  if (!ext) return fail("仅支持 PNG / JPG / WEBP / GIF");
  const body = await file.arrayBuffer();
  const key = `uploads/library/${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
  const url = await saveToR2(c, key, body, file.type);
  return ok({ url });
});

// —— 管理端：图片库 ——

app.use("/admin/*", requireAuth, requireAdmin);

// 列出图库图片（tab=mine 仅上传的；tab=system 含系统默认图片 assets/img/*；tab=all 两者）
// 每项带 in_use 标记：检查图片 key 是否被站点内容（site_content）引用
app.get("/admin/library", async (c) => {
  const bucket = c.env.ASSETS;
  if (!bucket) return fail("R2 未绑定", 503);
  const tab = c.req.query("tab") === "system" ? "system" : c.req.query("tab") === "all" ? "all" : "mine";

  // 使用中检测：站点内容 JSON 中出现的 key 都算被引用
  const contentRow = await c.env.DB.prepare(
    "SELECT value FROM site_settings WHERE key = 'site_content'",
  ).first<{ value: string }>();
  const contentBlob = contentRow?.value ?? "";

  // 自定义名称（图库重命名）
  const nameRows = await c.env.DB.prepare("SELECT key, name FROM image_meta").all<{ key: string; name: string }>();
  const nameMap = new Map((nameRows.results ?? []).map((r) => [r.key, r.name]));

  const listPrefix = async (prefix: string, limit: number) => {
    const listed = await bucket.list({ prefix, limit });
    return listed.objects.map((o) => ({
      key: o.key,
      url: `/static/${o.key}`,
      size: o.size,
      uploaded: o.uploaded?.toISOString() ?? null,
      system: o.key.startsWith("assets/img/"),
      in_use: contentBlob.includes(o.key),
      name: nameMap.get(o.key) || "",
    }));
  };

  if (tab === "system") {
    return ok(await listPrefix("assets/img/", 300));
  }

  const uploads = await listPrefix("uploads/library/", 200);
  if (tab === "all") {
    const system = await listPrefix("assets/img/", 300);
    return ok([...system, ...uploads]);
  }
  return ok(uploads);
});

// 删除图片（仅限 uploads/ 前缀；assets/img/ 为系统级资源，禁止删除）
app.post("/admin/library/delete", async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const key = String(body.key || "");
  if (key.startsWith("assets/img/")) {
    return fail("系统默认图片不可删除。如需调整请更新部署包中的 public 图片资源。");
  }
  if (!key.startsWith("uploads/")) return fail("非法路径");
  const bucket = c.env.ASSETS;
  if (!bucket) return fail("R2 未绑定", 503);
  await bucket.delete(key);
  return ok({ deleted: true });
});

// 重命名图片（存 image_meta，不影响 R2 对象；系统图片也可命名）
app.post("/admin/library/rename", async (c) => {
  const admin = c.get("user")!;
  const body = await c.req.json().catch(() => ({}));
  const key = String(body.key || "").slice(0, 300);
  const name = String(body.name ?? "").trim().slice(0, 100);
  if (!key || !(key.startsWith("uploads/") || key.startsWith("assets/"))) {
    return fail("非法路径");
  }
  await c.env.DB.prepare(
    `INSERT INTO image_meta (key, name, updated_at) VALUES (?, ?, datetime('now'))
     ON CONFLICT(key) DO UPDATE SET name = excluded.name, updated_at = datetime('now')`,
  )
    .bind(key, name)
    .run();
  await logOp(c.env.DB, c, admin.id, "image_rename", key);
  return ok({ renamed: true, name });
});

export default app;